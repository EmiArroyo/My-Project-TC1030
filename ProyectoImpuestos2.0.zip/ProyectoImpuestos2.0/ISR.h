//
// Created by Emilio Arroyo on 10/06/25.
//

#ifndef ISR_H
#define ISR_H
#include "Impuesto.h"



class ISR : public Impuesto{
public:
    ISR(double tasa);
    double calcularImpuesto(double ingresosAnuales) const;
    void mostrar() const;
};

#endif //ISR_H
