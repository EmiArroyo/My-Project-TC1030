//
// Created by Emilio Arroyo on 10/06/25.
//

#include "Impuesto.h"

Impuesto ::Impuesto(const std::string& nombre, double tasa)
    : nombre(nombre), tasa(tasa) {}

void Impuesto::mostrar() const {
    std::cout<<"Impuesto: "<<nombre<<", Tasa: " <<tasa << "%" << std::endl;
}
std::string Impuesto::getNombre() const {
    return nombre;
}
double Impuesto::getTasa() const {
    return tasa;
}
std::ostream& operator<<(std::ostream& os, const Impuesto& impuesto) {
    impuesto.mostrar();
    return os;
}