//
// Created by Emilio Arroyo on 10/06/25.
//

#include "IVA.h"
#include <iostream>

IVA ::IVA(double tasa) : Impuesto("IVA", tasa) {}

double IVA:: calcularImpuesto(double consumoAnual) const {
    return consumoAnual* (getTasa() / 100.0);

}
void IVA :: mostrar() const {
    std::cout<< "Impuesto al Valor Agregado (IVA), Tasa: " << getTasa()<<"%"<<std::endl;

}
