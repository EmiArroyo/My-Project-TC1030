//
// Created by Emilio Arroyo on 10/06/25.
//

#ifndef IVA_H
#define IVA_H
#include "Impuesto.h"


class IVA : public Impuesto {
public:
    IVA(double tasa);

    double calcularImpuesto(double consumoAnual) const;

    void mostrar() const;

};



#endif //IVA_H
