#include <iostream>
#include <vector>
#include "ISR.h"
#include "IVA.h"
#include "Predial.h"
#include "Tenencia.h"

using namespace std;

int SIyNO(const string& mensaje) {
    int respuesta;
    do {
        cout << mensaje;
        cin >> respuesta;

        if (respuesta != 0 && respuesta != 1) {
            cout << "Respuesta inválida. Por favor ingrese 1 para Sí o 0 para No.\n";
        }
    } while (respuesta != 0 && respuesta != 1);

    return respuesta;
}
int main() {

    string rfc;
    cout << "Ingrese su RFC: ";
    cin >> rfc;


    double ingresos, consumo;
    cout << "Ingrese sus ingresos anuales (MXN): ";
    cin >> ingresos;

    cout << "Ingrese su consumo anual (MXN): ";
    cin >> consumo;


    bool tieneCasa = SIyNO("¿Tiene casa? (1: Sí, 0: No): ");

    double valorInmueble = 0.0;
    if (tieneCasa) {
        cout << "Ingrese el valor de su inmueble (MXN): ";
        cin >> valorInmueble;
    }


    bool tieneVehiculo = SIyNO("¿Tiene vehiculo? (1: Sí, 0: No): ");

    double valorVehiculo = 0.0;
    if (tieneVehiculo) {
        cout << "Ingrese el valor de su vehiculo (MXN): ";
        cin >> valorVehiculo;
    }

    ISR isr(30.0);
    IVA iva(16.0);
    Predial predial(0.5);
    Tenencia tenencia(3.0);


    vector<Impuesto*> impuestos = {&isr, &iva,};


    if (tieneCasa) {
        impuestos.push_back(&predial);
    }
    if (tieneVehiculo) {
        impuestos.push_back(&tenencia);
    }


    cout << "\n----- Resumen de impuestos anuales para RFC: " << rfc << " -----" << endl;

    for (const auto& imp : impuestos) {
        cout << *imp;

        double base = 0.0;

        if (imp->getNombre() == "ISR") {
            base = ingresos;
        } else if (imp->getNombre() == "IVA") {
            base = consumo;
        } else if (imp->getNombre() == "Predial") {
            base = valorInmueble;
        } else if (imp->getNombre() == "Tenencia") {
            base = valorVehiculo;
        }

        double monto = imp->calcularImpuesto(base);
        cout << "Monto a pagar: $" << monto << "\n" << endl;
    }

    cout << "----- Fin del resumen de impuestos -----" << endl;

    return 0;
}