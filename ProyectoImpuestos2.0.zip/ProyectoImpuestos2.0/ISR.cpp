//
// Created by Emilio Arroyo on 10/06/25.
//

#include "ISR.h"
#include <iostream>

ISR ::ISR (double tasa): Impuesto("ISR", tasa){}

double ISR::calcularImpuesto(double ingresosAnuales) const {
    return ingresosAnuales * (getTasa() / 100.0);

}
void ISR::mostrar()const {
    std::cout << "Impuesto Sobre la Renta (ISR), Tasa: "<< getTasa() << "%" <<std::endl;
}
