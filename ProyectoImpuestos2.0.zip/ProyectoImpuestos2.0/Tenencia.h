//
// Created by Emilio Arroyo on 10/06/25.
//

#ifndef TENENCIA_H
#define TENENCIA_H

#include "Impuesto.h"

class Tenencia : public Impuesto {
public:
    Tenencia(double tasa);

    double calcularImpuesto(double valorVehiculo) const;

    void mostrar() const;
};

#endif
