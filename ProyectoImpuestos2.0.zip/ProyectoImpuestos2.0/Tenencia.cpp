//
// Created by Emilio Arroyo on 10/06/25.
//

#include "Tenencia.h"
#include <iostream>

Tenencia::Tenencia(double tasa) : Impuesto("Tenencia", tasa) {}


double Tenencia::calcularImpuesto(double valorVehiculo) const {
    return valorVehiculo * (getTasa() / 100.0);
}

void Tenencia::mostrar() const {
    std::cout << "Impuesto de Tenencia Vehicular, Tasa: " << getTasa() << "%" << std::endl;
}
