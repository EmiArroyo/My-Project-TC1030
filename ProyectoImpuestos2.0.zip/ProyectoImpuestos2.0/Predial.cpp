//
// Created by Emilio Arroyo on 10/06/25.
//

#include "Predial.h"
#include <iostream>

Predial::Predial(double tasa) : Impuesto("Predial", tasa) {}

double Predial::calcularImpuesto(double valorInmueble) const {
    return valorInmueble * (getTasa() / 100.0);
}


void Predial::mostrar() const {
    std::cout << "Impuesto Predial, Tasa: " << getTasa() << "%" << std::endl;
}
