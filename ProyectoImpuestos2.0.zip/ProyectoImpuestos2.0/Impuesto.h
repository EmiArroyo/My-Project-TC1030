//
// Created by Emilio Arroyo on 10/06/25.
//

#ifndef IMPUESTO_H
#define IMPUESTO_H
#include <iostream>
#include <string>


class Impuesto {
private:
    std::string nombre;
    double tasa;
public:
    Impuesto(const std ::string &nombre,  double tasa);
    virtual double calcularImpuesto(double base) const = 0;
    void mostrar() const;
    std :: string getNombre() const;
    double getTasa() const;
};
std :: ostream & operator << (std :: ostream &os, const Impuesto &impuesto);




#endif //IMPUESTO_H

virtual double calcularImpuesto(double base) const = 0;

// Nueva función sobrecargada
virtual double calcularImpuesto(double base, double deduccion) const {
    return calcularImpuesto(base - deduccion);
}
