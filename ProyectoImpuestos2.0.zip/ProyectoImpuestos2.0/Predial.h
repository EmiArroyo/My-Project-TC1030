//
// Created by Emilio Arroyo on 10/06/25.
//

#ifndef PREDIAL_H
#define PREDIAL_H

#include "Impuesto.h"

class Predial : public Impuesto {
public:
    Predial(double tasa);

    double calcularImpuesto(double valorInmueble) const;

    void mostrar() const;
};

#endif
